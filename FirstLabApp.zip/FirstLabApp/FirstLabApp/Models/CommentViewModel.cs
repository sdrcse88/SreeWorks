﻿namespace FirstLabApp.Models
{
    public class CommentViewModel
    {
        public int PostID { get; set; }
        public int ID { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Body { get; set; }
    }
}

﻿using FirstLabApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Text.Json;

namespace FirstLabApp.Components
{
    public class CommentsViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke(int Id)
        {
            var comments = new List<CommentViewModel>();
            string URL = "https://jsonplaceholder.typicode.com/posts/";
            string param = Id + "/comments";
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);
            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));

            // List data response.
            HttpResponseMessage response = client.GetAsync(param).Result;  // Blocking call! Program will wait here until a response is received or a timeout occurs.
            if (response.IsSuccessStatusCode)
            {
                var readTask = response.Content.ReadFromJsonAsync<List<CommentViewModel>>();

                readTask.Wait();

                comments = readTask.Result;
            }

            return View("~/Views/Components/_PostComment.cshtml", comments);
        }
    }
}
